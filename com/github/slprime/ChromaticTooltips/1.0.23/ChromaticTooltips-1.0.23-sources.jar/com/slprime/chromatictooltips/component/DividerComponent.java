package com.slprime.chromatictooltips.component;

import com.slprime.chromatictooltips.api.ITooltipComponent;
import com.slprime.chromatictooltips.api.TooltipContext;
import com.slprime.chromatictooltips.util.TooltipFontContext;

public class DividerComponent extends SpaceComponent {

    protected int colorCodeIndex = -1;
    protected int marginLeft = 0;

    public DividerComponent(SpaceComponent space, int marginLeft, int colorCodeIndex) {
        super(space);
        this.colorCodeIndex = colorCodeIndex;
        this.marginLeft = marginLeft;
    }

    @Override
    public ITooltipComponent[] paginate(TooltipContext context, int maxWidth, int maxHeight) {
        return new ITooltipComponent[] { this };
    }

    @Override
    public void draw(int x, int y, int availableWidth, TooltipContext context) {
        this.mixColor = (0xFF << 24) | TooltipFontContext.getColor(this.colorCodeIndex);
        super.draw(x + this.marginLeft, y, availableWidth - this.marginLeft, context);
    }

    @Override
    public String toString() {
        return "DividerTooltipComponent{height=" + this.height + ", colorCodeIndex=" + this.colorCodeIndex + "}";
    }

}
