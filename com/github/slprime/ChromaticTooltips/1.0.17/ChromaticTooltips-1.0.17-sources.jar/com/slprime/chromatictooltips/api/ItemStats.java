package com.slprime.chromatictooltips.api;

import java.util.UUID;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.StatCollector;

import com.gtnewhorizon.gtnhlib.util.numberformatting.NumberFormatUtil;
import com.slprime.chromatictooltips.component.ItemAttributeComponent;
import com.slprime.chromatictooltips.component.TextComponent;
import com.slprime.chromatictooltips.util.TooltipUtils;

public class ItemStats {

    public static class ArmorStats extends ItemStats {

        public ArmorStats(int damageReduceAmount) {
            super(
                TooltipUtils
                    .translate("enricher.attributes.armor.text", NumberFormatUtil.formatNumber(damageReduceAmount)),
                TooltipUtils
                    .translate("enricher.attributes.armor.icon", NumberFormatUtil.formatNumber(damageReduceAmount)),
                damageReduceAmount,
                "attributes/armor.png");
        }

    }

    public static class AttackDamageStats extends ItemStats {

        public AttackDamageStats(double attackDamage) {
            super(
                StatCollector.translateToLocal("attribute.name.generic.attackDamage"),
                attackDamage,
                StatsOperator.ADDITION,
                "attributes/attack_damage.png");
        }

    }

    public static class MaxHealthStats extends ItemStats {

        public MaxHealthStats(double maxHealth) {
            super(
                StatCollector.translateToLocal("attribute.name.generic.maxHealth"),
                maxHealth,
                StatsOperator.ADDITION,
                "attributes/max_health.png");
        }

    }

    public static class KnockbackResistanceStats extends ItemStats {

        public KnockbackResistanceStats(double knockbackResistance) {
            super(
                StatCollector.translateToLocal("attribute.name.generic.knockbackResistance"),
                knockbackResistance,
                StatsOperator.ADDITION,
                "attributes/knockback_resistance.png");
        }

    }

    public static class MovementSpeedStats extends ItemStats {

        public MovementSpeedStats(double movementSpeed) {
            super(
                StatCollector.translateToLocal("attribute.name.generic.movementSpeed"),
                movementSpeed,
                StatsOperator.ADDITION,
                "attributes/movement_speed.png");
        }

    }

    public static class UnbreakableStats extends ItemStats {

        public UnbreakableStats() {
            super(StatCollector.translateToLocal("item.unbreakable"), null, 0, null);
        }

        @Override
        public int getOrder() {
            return -10_000;
        }

    }

    public static class DurabilityStats extends ItemStats {

        public DurabilityStats(int durability, int maxDurability) {
            super(
                TooltipUtils.translate(
                    "enricher.attributes.durability.text",
                    NumberFormatUtil.formatNumber(durability),
                    NumberFormatUtil.formatNumber(maxDurability)),
                TooltipUtils.translate(
                    "enricher.attributes.durability.icon",
                    NumberFormatUtil.formatNumber(durability),
                    NumberFormatUtil.formatNumber(maxDurability)),
                durability,
                "attributes/durability.png");
        }

        @Override
        public int getOrder() {
            return -10_010;
        }

    }

    public static class BurnTimeStats extends ItemStats {

        public BurnTimeStats(int burnTime) {
            super(
                TooltipUtils.translate("enricher.attributes.fuel.text", NumberFormatUtil.formatNumber(burnTime)),
                TooltipUtils.translate("enricher.attributes.fuel.icon", NumberFormatUtil.formatNumber(burnTime)),
                burnTime,
                "attributes/fuel.png");
        }

    }

    public static class HungerStats extends ItemStats {

        public HungerStats(double hunger) {
            super(
                TooltipUtils.translate("enricher.attributes.hunger.text", NumberFormatUtil.formatNumber(hunger / 2f)),
                TooltipUtils.translate("enricher.attributes.hunger.icon", NumberFormatUtil.formatNumber(hunger / 2f)),
                hunger,
                "attributes/hunger.png");
        }

        public int getOrder() {
            return 10_001;
        }

    }

    public static class SaturationStats extends ItemStats {

        public SaturationStats(double saturation) {
            super(
                TooltipUtils
                    .translate("enricher.attributes.saturation.text", NumberFormatUtil.formatNumber(saturation / 2f)),
                TooltipUtils
                    .translate("enricher.attributes.saturation.icon", NumberFormatUtil.formatNumber(saturation / 2f)),
                saturation,
                "attributes/saturation.png");
        }

        public int getOrder() {
            return 10_000;
        }

    }

    public static class PotionEffectStats extends ItemStats {

        public PotionEffectStats(String textLine, int duration) {
            super(textLine, null, duration, null);
        }

        public static PotionEffectStats of(PotionEffect potionEffect, float probability) {
            String textLine = StatCollector.translateToLocal(potionEffect.getEffectName())
                .trim();
            final boolean isBadEffect = Potion.potionTypes[potionEffect.getPotionID()].isBadEffect();
            final int amplifier = potionEffect.getAmplifier();

            if (amplifier > 0) {
                final String potencyKey = "enchantment.level." + (amplifier + 1);
                final String potency = StatCollector.translateToLocal(potencyKey);
                textLine += " "
                    + (potency.equals(potencyKey) ? NumberFormatUtil.formatNumber(amplifier + 1) : potency.trim());
            }

            if (probability < 1.0F) {
                final String key = isBadEffect ? "enricher.attributes.food.potion.text.minus.probability"
                    : "enricher.attributes.food.potion.text.plus.probability";
                textLine = TooltipUtils
                    .translate(key, textLine, Potion.getDurationString(potionEffect), Math.round(probability * 100.0F));
            } else {
                final String key = isBadEffect ? "enricher.attributes.food.potion.text.minus"
                    : "enricher.attributes.food.potion.text.plus";
                textLine = TooltipUtils.translate(key, textLine, Potion.getDurationString(potionEffect));
            }

            return new PotionEffectStats(textLine, potionEffect.getDuration() / 1200);
        }

        public static PotionEffectStats of(PotionEffect potionEffect) {
            return of(potionEffect, 1.0F);
        }

    }

    public static enum StatsOperator {

        ADDITION(0, "addition"), // +5 Damage
        MULTIPLY_BASE(1, "percent"), // +10% Damage
        MULTIPLY_TOTAL(2, "percent"); // +10% Damage after all modifiers

        private final int operation;
        private final String key;

        StatsOperator(int operation, String key) {
            this.operation = operation;
            this.key = key;
        }

        public int getOperation() {
            return this.operation;
        }

        public String getKey() {
            return this.key;
        }

        public static StatsOperator fromOperation(int operation) {
            for (StatsOperator op : values()) {
                if (op.getOperation() == operation) {
                    return op;
                }
            }
            return null;
        }

    }

    // copied from Item
    protected static final UUID ITEM_UUID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");

    protected String textLine;
    protected String iconLine;
    protected double value;
    protected String icon;

    public ItemStats(String textLine, String iconLine, double value, String icon) {
        this.textLine = textLine;
        this.iconLine = iconLine;
        this.value = value;
        this.icon = icon;
    }

    public ItemStats(String attributeName, double value, StatsOperator operator, String icon) {
        final String attributeValue = NumberFormatUtil.formatNumber(Math.abs(value));
        final String dir = value >= 0 ? "plus" : "minus";

        this.textLine = TooltipUtils
            .translate("enricher.attributes." + operator.getKey() + ".text." + dir, attributeValue, attributeName);
        this.iconLine = TooltipUtils
            .translate("enricher.attributes." + operator.getKey() + ".icon." + dir, attributeValue);
        this.value = value;
        this.icon = icon;
    }

    public ItemStats withIcon(String icon) {
        this.icon = icon;
        return this;
    }

    public boolean hasIcon() {
        return this.icon != null;
    }

    public double getValue() {
        return this.value;
    }

    public int getOrder() {
        return (int) (100 * this.value);
    }

    public static double getModifiedAmount(AttributeModifier modifier, ItemStack stack) {
        double amount = modifier.getAmount();

        if (modifier.getID() == ITEM_UUID) {
            amount += EnchantmentHelper.func_152377_a(stack, EnumCreatureAttribute.UNDEFINED);
        }

        if (modifier.getOperation() != 0) {
            amount *= 100;
        }

        return amount;
    }

    public ITooltipComponent getIconComponent() {

        if (this.icon != null && this.iconLine != null) {
            return new ItemAttributeComponent(this.icon, this.iconLine);
        }

        return null;
    }

    public ITooltipComponent getTextComponent() {
        return this.textLine != null
            ? new TextComponent(TooltipUtils.applyBaseColorIfAbsent(this.textLine, TooltipLines.BASE_COLOR))
            : null;
    }

    public String getTextLine() {
        return this.textLine;
    }

}
